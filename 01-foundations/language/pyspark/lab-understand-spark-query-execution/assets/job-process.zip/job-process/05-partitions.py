# Databricks notebook source
# MAGIC %run ./00-s3-integration

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Input Partitions

# COMMAND ----------

display(dbutils.fs.ls("s3a://wysde-datasets/spark/Customer/csvFiles"))

# COMMAND ----------

df = spark.read.format("csv").option("header","true").load("s3a://wysde-datasets/spark/Customer/csvFiles")

# COMMAND ----------

print(spark.conf.get("spark.sql.files.maxPartitionBytes"))

# COMMAND ----------

df.rdd.getNumPartitions()

# COMMAND ----------

spark.conf.set("spark.sql.files.maxPartitionBytes", "134217728") # 128 MB

# COMMAND ----------

spark.conf.set("spark.sql.files.maxPartitionBytes", "1048576") # 16 MB

# COMMAND ----------

df = spark.read.format("csv").option("header","true").load("s3a://wysde-datasets/spark/Customer/csvFiles")
df.rdd.getNumPartitions()

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Output Partitions

# COMMAND ----------

df = spark.read.format("csv").option("header","true").load("s3a://wysde-datasets/spark/Customer/csvFiles")

# COMMAND ----------

spark.conf.set("spark.sql.files.maxPartitionBytes", "134217728") # 128 MB
df = spark.read.format("csv").option("header","true").load("s3a://wysde-datasets/spark/Customer/csvFiles")
print(f"Number of partitions = {df.rdd.getNumPartitions()}")
df.write.mode("overwrite").option("path", "dbfs:/tmp/datasources/customerSingleFile/").saveAsTable("customerSingleFile")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from customerSingleFile limit 10

# COMMAND ----------

# MAGIC %fs ls dbfs:/tmp/datasources/customerSingleFile

# COMMAND ----------

repartitionedDF = df.repartition(8)
print('Number of partitions: {}'.format(repartitionedDF.rdd.getNumPartitions()))

# COMMAND ----------

repartitionedDF = df.repartition('C_MKTSEGMENT')
print('Number of partitions: {}'.format(repartitionedDF.rdd.getNumPartitions()))

# COMMAND ----------

coalescedDF = df.coalesce(2)
print('Number of partitions: {}'.format(coalescedDF.rdd.getNumPartitions()))

# COMMAND ----------

df.write.option("maxRecordsPerFile", 1000).mode("overwrite").partitionBy("C_MKTSEGMENT").option("path", "dbfs:/tmp/datasources/customer/parquet/maxfiles/").saveAsTable("customer_maxfiles")

# COMMAND ----------

# MAGIC %fs ls dbfs:/tmp/datasources/customer/parquet/maxfiles/C_MKTSEGMENT=BUILDING/

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Shuffle Partitions

# COMMAND ----------

df = spark.read.format("csv").option("header","true").load("s3a://wysde-datasets/spark/Customer/csvFiles")

# COMMAND ----------

# Check the duration of execution with default 200 partitions 
spark.conf.set("spark.sql.shuffle.partitions", 200)
mktSegmentDF = df.groupBy("C_MKTSEGMENT").count().collect()

# COMMAND ----------

# Check the duration of execution with default 30 partitions 
spark.conf.set("spark.sql.shuffle.partitions", 30)
mktSegmentDF = df.groupBy("C_MKTSEGMENT").count().collect()

# COMMAND ----------

