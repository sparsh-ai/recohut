# Databricks notebook source
# !mkdir -p ~/.aws

# COMMAND ----------

# %%writefile ~/.aws/credentials
# [default]
# aws_access_key_id=
# aws_secret_access_key=
# region=us-east-1
# output=json

# COMMAND ----------

import boto3
session = boto3.Session(profile_name='default')
credentials = session.get_credentials()

sc._jsc.hadoopConfiguration().set("fs.s3a.access.key", credentials.access_key)
sc._jsc.hadoopConfiguration().set("fs.s3a.secret.key", credentials.secret_key)
aws_region = "us-east-1"
sc._jsc.hadoopConfiguration().set("fs.s3a.endpoint", "s3." + aws_region + ".amazonaws.com")

# COMMAND ----------

